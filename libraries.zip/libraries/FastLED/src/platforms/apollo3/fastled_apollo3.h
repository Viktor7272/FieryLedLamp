#ifndef __INC_FASTLED_APOLLO3_H
#define __INC_FASTLED_APOLLO3_H

#include "fastpin_apollo3.h"
#include "fastspi_apollo3.h"
#include "clockless_apollo3.h"

#endif
